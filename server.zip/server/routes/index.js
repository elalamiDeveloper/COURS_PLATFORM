import { usersRouter } from './usersRoute.js';
import { formationsRouter } from './formationsRouter.js';

export { usersRouter, formationsRouter };
