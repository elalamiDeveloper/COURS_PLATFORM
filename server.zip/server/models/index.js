import User from './userModel.js';

export { User };
